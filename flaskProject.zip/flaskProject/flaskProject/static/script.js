let map;
let userCoords;

// Inicializar el mapa de Leaflet
function initMap() {
    map = L.map('map').setView([40.416775, -3.703790], 5);  // Vista inicial centrada en España

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
}

// Mostrar los embalses en el mapa y en la tabla
function displayEmbalses(embalses) {
    $('#embalsesTable tbody').empty();  // Limpiar la tabla
    map.eachLayer(function (layer) {
        if (layer instanceof L.Marker) {
            map.removeLayer(layer);  // Limpiar marcadores anteriores
        }
    });

    embalses.forEach(embalse => {
        // Añadir marcador en el mapa
        L.marker([embalse.latitude, embalse.longitude]).addTo(map)
            .bindPopup(`<strong>${embalse.name}</strong><br>${embalse.province}<br>Capacidad: ${embalse.capacity} hm³`);

        // Añadir fila a la tabla
        $('#embalsesTable tbody').append(`
            <tr>
                <td>${embalse.name}</td>
                <td>${embalse.province}</td>
                <td>${embalse.capacity}</td>
                <td>(${embalse.latitude}, ${embalse.longitude})</td>
                <td>${embalse.distance.toFixed(2)}</td>
                <td>${embalse.water_stored}</td>
            </tr>
        `);
    });

    // Ajustar el mapa para mostrar todos los marcadores
    if (embalses.length > 0) {
        const group = L.featureGroup(embalses.map(embalse => L.marker([embalse.latitude, embalse.longitude])));
        map.fitBounds(group.getBounds());
    }
}

// Obtener la ubicación del usuario
$('#useLocationBtn').on('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async position => {
            userCoords = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            };
            await fetchEmbalses(userCoords.latitude, userCoords.longitude, 100);
        }, () => {
            alert('No se pudo obtener la ubicación. Asegúrate de que los servicios de ubicación estén habilitados.');
        });
    } else {
        alert('La geolocalización no está soportada por este navegador.');
    }
});

// Mostrar el formulario para ingresar coordenadas manuales
$('#customLocationBtn').on('click', () => {
    $('#customLocationForm').toggle();
});

// Obtener embalses al introducir coordenadas manualmente
$('#submitCoordinates').on('click', async () => {
    const latitude = $('#latitude').val();
    const longitude = $('#longitude').val();
    const radius = $('#radius').val() || 100;
    await fetchEmbalses(latitude, longitude, radius);
});

// Fetch embalses API
async function fetchEmbalses(lat, lon, radius) {
    try {
        $('.loading-spinner').show();
        const response = await fetch(`/api/embalses?lat=${lat}&lon=${lon}&radius=${radius}`);
        const data = await response.json();
        $('.loading-spinner').hide();

        if (data.error) {
            alert(data.error);
        } else {
            displayEmbalses(data.embalses);
        }
    } catch (error) {
        $('.loading-spinner').hide();
        alert('Error al obtener los datos de los embalses.');
    }
}

$(document).ready(function() {
    initMap();
    $('#embalsesTable').DataTable();  // Inicializar DataTable
});