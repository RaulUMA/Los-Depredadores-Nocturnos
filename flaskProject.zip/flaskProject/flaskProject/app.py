from flask import Flask, jsonify, request, render_template
import requests
import math
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Limitar el número de solicitudes para evitar abusos
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["200 per day", "50 per hour"]
)

API_EMBALSES_URL = 'https://gb0a5b4221c5acb-reto.adb.eu-madrid-1.oraclecloudapps.com/ords/us1/embalse/'
API_AGUA_URL = 'https://gb0a5b4221c5acb-reto.adb.eu-madrid-1.oraclecloudapps.com/ords/us1/agua/'
API_LISTADO_URL = 'https://gb0a5b4221c5acb-reto.adb.eu-madrid-1.oraclecloudapps.com/ords/us1/listado/'


@app.route('/')
def index():
    return render_template('index.html')


def haversine(lat1, lon1, lat2, lon2):
    """Calcula la distancia entre dos coordenadas en km usando la fórmula Haversine."""
    R = 6371  # Radio de la Tierra en km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = R * c
    return distance


def obtener_estadisticas(embalses):
    """Obtiene las estadísticas de agua total en los embalses."""
    total_agua = [embalse['agua_total'] for embalse in embalses]
    max_agua = max(total_agua)
    min_agua = min(total_agua)
    promedio_agua = sum(total_agua) / len(total_agua)

    return {
        'max': max_agua,
        'min': min_agua,
        'promedio': promedio_agua
    }


@app.route('/api/embalses', methods=['GET'])
@limiter.limit("10 per minute")
def get_embalses():
    lat = float(request.args.get('lat'))
    lon = float(request.args.get('lon'))
    radius = float(request.args.get('radius', 100))

    response = requests.get(API_EMBALSES_URL)
    if response.status_code == 200:
        embalses = response.json().get('items', [])
        embalses_cercanos = [
            embalse for embalse in embalses if haversine(lat, lon, embalse['x'], embalse['y']) <= radius
        ]
        return jsonify({'items': embalses_cercanos})
    else:
        return jsonify({'error': 'Error al obtener datos de embalses'}), response.status_code


@app.route('/api/agua', methods=['GET'])
def get_agua():
    response = requests.get(API_AGUA_URL)
    if response.status_code == 200:
        return jsonify({'items': response.json().get('items', [])})
    else:
        return jsonify({'error': 'Error al obtener datos de agua'}), response.status_code


@app.route('/api/listado', methods=['GET'])
def get_listado():
    response = requests.get(API_LISTADO_URL)
    if response.status_code == 200:
        return jsonify({'items': response.json().get('items', [])})
    else:
        return jsonify({'error': 'Error al obtener listado de embalses'}), response.status_code


@app.route('/api/estadisticas', methods=['GET'])
def get_estadisticas():
    response = requests.get(API_EMBALSES_URL)
    if response.status_code == 200:
        embalses = response.json().get('items', [])
        stats = obtener_estadisticas(embalses)
        return jsonify(stats)
    else:
        return jsonify({'error': 'Error al obtener estadísticas de embalses'}), response.status_code


if __name__ == '__main__':
    app.run(debug=True)
